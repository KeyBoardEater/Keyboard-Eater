Keyboard-Eater
=============
RoundConnerImageView自定义圆角控件，支持通过xml快捷设置所有圆角半径或者四个角中任何一个圆角半径
