package com.keyboardeater.widget.aop;


public class TestAspectJ {

    private static final String TAG ="TestAspectJ";

//    @Pointcut("target(com.keyboardeater.widget.layoutmanager.CustomLayoutManager)")
//    public void TestMainActivity(){}
//
//    @Pointcut("execution(*.log(*))")
//    public void TestOnCreate(){}
//
//
//    @Before("TestMainActivity() && TestOnCreate ()")
//    public void testActivityOnCreate(){
//        Log.d("TestAspectJ", " Wearver Success");
//    }
}
