package com.keyboardeater.widget.timeline.bean

import android.graphics.Rect
import java.util.*

interface TimeLine {

    fun getTimeText():String

}